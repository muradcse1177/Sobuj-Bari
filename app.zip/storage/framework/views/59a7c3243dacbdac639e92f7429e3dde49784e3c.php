<?php $__env->startSection('title', 'Project-Details'); ?>
<?php $__env->startSection('cu', 'current'); ?>
<?php $__env->startSection('content'); ?>

    <?php
        use Illuminate\Support\Facades\DB;
            $rows = DB::table('company_info')->first();
            $services = DB::table('services')->get();
    ?>
    <section class="main-slider">
        <div class="rev_slider_wrapper fullwidthbanner-container"  id="rev_slider_one_wrapper" data-source="gallery">
            <div class="rev_slider fullwidthabanner" id="rev_slider_one" data-version="5.4.1">
                <ul>
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1687" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-1.jpg" data-title="Slide Title" data-transition="parallaxvertical">
                            <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="<?php echo e(url('public/images/'.$slide->slide)); ?>">
                            <div class="tp-caption"
                                 data-paddingbottom="[0,0,0,0]"
                                 data-paddingleft="[0,0,0,0]"
                                 data-paddingright="[0,0,0,0]"
                                 data-paddingtop="[0,0,0,0]"
                                 data-responsive_offset="on"
                                 data-type="text"
                                 data-height="none"
                                 data-width="['720','720','650','450']"
                                 data-whitespace="normal"
                                 data-hoffset="['15','15','15','15']"
                                 data-voffset="['-100','-110','-70','-75']"
                                 data-x="['right','right','right','right']"
                                 data-y="['middle','middle','middle','middle']"
                                 data-textalign="['top','top','top','top']"
                                 data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="contact-number"><span class="icon flaticon-phone-call"></span>Call Us: +8801707011562</div>
    </section>
    <section class="call-to-action-section-two" style="background-image:url(public/images/background/7.jpg)">
        <div class="auto-container">
            <div class="row clearfix">

                <div class="column col-md-7 col-sm-12 col-xs-12">
                    <h2><span class="theme_color">Construction</span> Company</h2>
                    <div class="text">If you have any construction & renovation work need, simply call our 24 hour emergency number.</div>
                </div>
                <div class="btn-column col-md-5 col-sm-12 col-xs-12">
                    <div class="number">+8801707011562 <span class="theme_color"> or </span> <a href="<?php echo e(url('contact')); ?>" class="theme-btn btn-style-five">Contact Us</a> </div>
                </div>

            </div>
        </div>
    </section>
    <section class="map-section">
        <!--Map Outer-->
        <div class="map-outer">
            <!--Map Canvas-->
            <div class="map-canvas"
                 data-zoom="10"
                 data-lat="23.798914766489954",
                 data-lng=" 90.40298054023401"
                 data-type="roadmap"
                 data-hue="#ffc400"
                 data-title="<?php echo e($rows->name); ?>"
                 data-icon-path="<?php echo e(url("public/images/icons/map-marker.png")); ?>"
                 data-content="<?php echo e($rows->address); ?><br><a href='mailto:<?php echo e($rows->email); ?>'><?php echo e($rows->email); ?></a>">
            </div>
        </div>
    </section>
    <section class="contact-section">
        <div class="auto-container">

            <h2><span class="theme_color">Get</span> in Touch</h2>
            <div class="text">You can talk to our online representative at any time. Please use our Live Chat System on our website or Fill up below instant messaging programs. <br> Please be patient, We will get back to you. Our 24/7 Support, General Inquiries Phone: +8801707011562</div>
            <div class="row clearfix">
                <div class="form-column col-lg-9 col-md-8 col-sm-12 col-xs-12">
                    <div class="inner-column">
                        <div class="contact-form style-two">
                            <div class="contact-form">
                                <?php echo e(Form::open(array('url' => 'send-mail',  'method' => 'post'))); ?>

                                <?php echo e(csrf_field()); ?>

                                <div class="row clearfix">
                                    <div class="row clearfix">
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="text" name="name" value="" placeholder="Name" required>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="email" name="email" value="" placeholder="Email" required>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="text" name="subject" value="" placeholder="Subject" required>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="text" name="phone" value="" placeholder="Phone" required>
                                        </div>
                                        <div class="form-group col-md-12 col-sm-12 co-xs-12">
                                            <textarea name="message" placeholder="Your Massage"></textarea>
                                        </div>
                                        <div class="form-group col-md-12 col-sm-12 co-xs-12">
                                            <button type="submit" class="theme-btn btn-style-one">Send Message</button>
                                        </div>
                                    </div>
                                </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                            <?php if($message = Session::get('successMessage')): ?>
                                <div class="alert alert-success alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <h4><i class="icon fa fa-check"></i> Thank You!!</h4>
                                    <?php echo e($message); ?></b>
                                </div>
                            <?php endif; ?>
                            <?php if($message = Session::get('errorMessage')): ?>

                                <div class="alert alert-warning alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <h4><i class="icon fa fa-warning"></i> Sorry!</h4>
                                    <?php echo e($message); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="info-column col-lg-3 col-md-4 col-sm-12 col-xs-12">

                    <ul class="list-style-two">
                        <li><span class="icon flaticon-home-1"></span><strong>Address</strong><?php echo e($rows->address); ?></li>
                        <li><span class="icon flaticon-envelope-1"></span><strong>Send your mail at</strong><?php echo e($rows->email); ?></li>
                        <li><span class="icon flaticon-technology-2"></span><strong>Have Any Question</strong><?php echo e($rows->phone); ?></li>
                        <li><span class="icon flaticon-clock-1"></span><strong>Working Hours</strong><?php echo e($rows->hours); ?></li>
                    </ul>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\arc\resources\views/website/contact.blade.php ENDPATH**/ ?>