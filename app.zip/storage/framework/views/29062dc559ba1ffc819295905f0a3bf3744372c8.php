<?php $__env->startSection('title', 'Received Email'); ?>
<?php $__env->startSection('page_header', 'Received Email'); ?>
<?php $__env->startSection('receivedEmail','active'); ?>
<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('successMessage')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-check"></i> Thank You!!</h4>
            <?php echo e($message); ?></b>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('errorMessage')): ?>

        <div class="alert alert-warning alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-warning"></i> Sorry!</h4>
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Received Email</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive">
                    <table class="table table-bordered">
                        <tr>
                            <th>Name </th>
                            <th>Email </th>
                            <th>Phone </th>
                            <th>Subject </th>
                            <th>Message </th>
                        </tr>
                        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($email->name); ?> </td>
                                <td> <?php echo e($email->email); ?> </td>
                                <td> <?php echo e($email->phone); ?> </td>
                                <td> <?php echo e($email->subject); ?> </td>
                                <td> <?php echo e($email->msg); ?> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\arc\resources\views/admin/receivedEmail.blade.php ENDPATH**/ ?>