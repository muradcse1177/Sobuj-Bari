<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('abb', 'current'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        use Illuminate\Support\Facades\DB;
            $rows = DB::table('company_info')->first();
            $services = DB::table('services')->get();
    ?>
    <section class="main-slider">
        <div class="rev_slider_wrapper fullwidthbanner-container"  id="rev_slider_one_wrapper" data-source="gallery">
            <div class="rev_slider fullwidthabanner" id="rev_slider_one" data-version="5.4.1">
                <ul>
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <img src="<?php echo e(url('public/images/'.$slide->slide)); ?>">
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="contact-number"><span class="icon flaticon-phone-call"></span>Call Us: <?php echo e($rows->phone); ?></div>
    </section>
    <section class="success-section">
        <div class="auto-container">
            <div class="row clearfix">

                <!--Image Column-->
                <div class="image-column col-md-5 col-sm-12 col-xs-12">
                    <div class="inner-column">
                        <div class="image">
                            <img src="<?php echo e(url('public/images/resource/success-1.jpg')); ?>" alt="" />
                        </div>
                        <div class="small-img">
                            <img src="<?php echo e(url('public/images/resource/success-2.jpg')); ?>" alt="" />
                        </div>
                    </div>
                </div>
                <!--Content Column-->
                <div class="content-column col-md-7 col-sm-12 col-xs-12">
                    <div class="inner-column">
                        <div class="since-year clearfix">
                            <span class="title">since</span>
                            <div class="year-img" style="font-size: 50px; color: black;"><b>2015</b></div>
                            <?php
                                $date1 = "2015-01-01";
                                $date2 = date('Y-m-d');
                                $diff = abs(strtotime($date2) - strtotime($date1));

                                $years = floor($diff / (365*60*60*24));
                                $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                            ?>
                            <div class="work"><?php echo e($years.' '); ?> Years OF<strong>Success</strong><span>Work</span></div>
                        </div>
                        <div class="text text-justify">Apparently we had reached a great height in the atmosphere for the sky was a dead black and the stars headcase to twinkle. We providing international construction services company and is a leading builder in diverse market segments. The company earned recognition for undertaking large, complex projects, fostering innovation, embracing emerging technologies and making a difference.</div>

                        <div class="fact-">
                            <div class="row clearfix">

                                <!--Column-->
                                <div class="column -column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="-outer -box">
                                            <span class="-text" style="font-size: 40px; color: black;" data-speed="3500" data-stop="200">85</span>
                                            <h4 class="-title">Projects</h4>
                                        </div>
                                    </div>
                                </div>

                                <!--Column-->
                                <div class="column -column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="-outer -box">
                                            <span class="-text" style="font-size: 40px; color: black;" data-speed="2500" data-stop="895">35</span>
                                            <h4 class="-title">Employers</h4>
                                        </div>
                                    </div>
                                </div>

                                <!--Column-->
                                <div class="column -column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="-outer -box">
                                            <span class="-text" style="font-size: 40px; color: black;" data-speed="2200" data-stop="954">251</span>
                                            <h4 class="-title">Customers</h4>
                                        </div>
                                    </div>
                                </div>

                                <!--Column-->
                                <div class="column -column col-md-3 col-sm-6 col-xs-12">
                                    <div class="inner">
                                        <div class="-outer -box">
                                            <span class="-text" style="font-size: 40px; color: black;" data-speed="2000" data-stop="25">03</span>
                                            <h4 class="-title">Awards</h4>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>
    <section class="fluid-section-one">
        <div class="outer-container clearfix">
            <!--Image Column-->
            <div class="image-column" style="background-image:url(public/images/resource/image-1.jpg);">
                <figure class="image-box"><img src="<?php echo e(url('public/images/resource/image-1.jpg')); ?>" alt=""></figure>
            </div>
            <!--Content Column-->
            <div class="content-column">
                <div class="inner-box">
                    <div class="sec-title">
                        <div class="title">Our Working Area</div>
                        <h2><span class="theme_color">About </span> Us</h2>
                    </div>
                    <div class="text text-justify"><?php echo nl2br($infos->about); ?></div>
                </div>
            </div>
        </div>
    </section>
    <section class="services-section-two" style="background-image:url(/images/background/4.jpg)">
        <div class="auto-container">
            <div class="sec-title centered">
                <div class="title">Services We Offer & Solutions</div>
                <h2><span class="theme_color">Our</span> Main Services</h2>
            </div>
            <div class="row clearfix">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="services-block-two col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="upper-box">
                                <div class="icon-box">
                                    <span class="icon flaticon-brick-wall"></span>
                                </div>
                                <h3><a href="<?php echo e(url('service?cat='.$service->id)); ?>"><?php echo e($service->title); ?></a></h3>
                            </div>
                            <div class="text text-justify"><?php echo e(substr($service->description,0,120).'...'); ?></div>
                            <a href="<?php echo e(url('service?cat='.$service->id)); ?>" class="read-more">Read More <span class="fa fa-angle-right"></span></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="call-to-action-section-two" style="background-image:url(public/images/background/7.jpg)">
        <div class="auto-container">
            <div class="row clearfix">

                <div class="column col-md-7 col-sm-12 col-xs-12">
                    <h2><span class="theme_color">Construction</span> Company</h2>
                    <div class="text">If you have any construction & renovation work need, simply call our 24 hour emergency number.</div>
                </div>
                <div class="btn-column col-md-5 col-sm-12 col-xs-12">
                    <div class="number">+8801707011562 <span class="theme_color"> or </span> <a href="<?php echo e(url('contact')); ?>" class="theme-btn btn-style-five">Contact Us</a> </div>
                </div>

            </div>
        </div>
    </section>
    <section class="contact-info-section">
        <!--Map Section-->
        <div class="map-section">
            <!--Map Outer-->
            <div class="map-outer">
                <!--Map Canvas-->
                <div class="map-canvas"
                     data-zoom="10"
                     data-lat="23.798914766489954",
                     data-lng=" 90.40298054023401"
                     data-type="roadmap"
                     data-hue="#ffc400"
                     data-title="<?php echo e($rows->name); ?>"
                     data-icon-path="<?php echo e(url("public/images/icons/map-marker.png")); ?>"
                     data-content="<?php echo e($rows->address); ?><br><a href='mailto:<?php echo e($rows->email); ?>'><?php echo e($rows->email); ?></a>">
                </div>
            </div>
        </div>
        <!--Map Section-->
        <div class="auto-container">
            <div class="inner-container">
                <div class="row clearfix">
                    <!--Info Column-->
                    <div class="info-column col-md-4 col-sm-12 col-xs-12">
                        <div class="inner-column">
                            <ul class="list-style-two">
                                <li><span class="icon flaticon-home-1"></span><strong>Address</strong><?php echo e($rows->address); ?></li>
                                <li><span class="icon flaticon-envelope-1"></span><strong>Send your mail at</strong><?php echo e($rows->email); ?></li>
                                <li><span class="icon flaticon-technology-2"></span><strong>Have Any Question</strong><?php echo e($rows->phone); ?></li>
                                <li><span class="icon flaticon-clock-1"></span><strong>Working Hours</strong><?php echo e($rows->hours); ?></li>
                            </ul>
                        </div>
                    </div>
                    <!--Form Column-->
                    <div class="form-column col-md-8 col-sm-12 col-xs-12">
                        <div class="inner-column">
                            <h2>Contact Us</h2>
                            <!--Contact Form-->
                            <div class="contact-form">
                                <?php echo e(Form::open(array('url' => 'send-mail',  'method' => 'post'))); ?>

                                <?php echo e(csrf_field()); ?>

                                <div class="row clearfix">
                                    <div class="row clearfix">
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="text" name="name" value="" placeholder="Name" required>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="email" name="email" value="" placeholder="Email" required>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="text" name="subject" value="" placeholder="Subject" required>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-6 co-xs-12">
                                            <input type="text" name="phone" value="" placeholder="Phone" required>
                                        </div>
                                        <div class="form-group col-md-12 col-sm-12 co-xs-12">
                                            <textarea name="message" placeholder="Your Massage"></textarea>
                                        </div>
                                        <div class="form-group col-md-12 col-sm-12 co-xs-12">
                                            <button type="submit" class="theme-btn btn-style-one">Send Message</button>
                                        </div>
                                    </div>
                                </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                            <?php if($message = Session::get('successMessage')): ?>
                                <div class="alert alert-success alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <h4><i class="icon fa fa-check"></i> Thank You!!</h4>
                                    <?php echo e($message); ?></b>
                                </div>
                            <?php endif; ?>
                            <?php if($message = Session::get('errorMessage')): ?>

                                <div class="alert alert-warning alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <h4><i class="icon fa fa-warning"></i> Sorry!</h4>
                                    <?php echo e($message); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sobujbar/public_html/resources/views/website/about.blade.php ENDPATH**/ ?>